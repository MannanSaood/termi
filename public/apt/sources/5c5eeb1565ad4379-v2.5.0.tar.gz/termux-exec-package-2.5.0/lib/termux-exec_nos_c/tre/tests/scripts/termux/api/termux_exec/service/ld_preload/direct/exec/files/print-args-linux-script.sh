#!/usr/bin/sh

echo "$@"
