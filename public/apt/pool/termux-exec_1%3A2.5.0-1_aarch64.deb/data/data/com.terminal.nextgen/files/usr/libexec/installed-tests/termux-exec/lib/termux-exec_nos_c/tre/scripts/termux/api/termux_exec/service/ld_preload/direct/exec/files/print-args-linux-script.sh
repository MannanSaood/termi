#!/data/data/com.terminal.nextgen/files/usr/bin/sh

echo "$@"
